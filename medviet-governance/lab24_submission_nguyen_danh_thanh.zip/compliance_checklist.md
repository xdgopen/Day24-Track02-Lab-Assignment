# NĐ13/2023 Compliance Checklist — MedViet AI Platform

## A. Data Localization
- [x] Tất cả patient data lưu trên servers đặt tại Việt Nam
- [x] Backup cũng phải ở trong lãnh thổ VN
- [x] Log việc transfer data ra ngoài nếu có

## B. Explicit Consent
- [x] Thu thập consent trước khi dùng data cho AI training
- [x] Có mechanism để user rút consent (Right to Erasure)
- [x] Lưu consent record với timestamp

## C. Breach Notification (72h)
- [x] Có incident response plan
- [x] Alert tự động khi phát hiện breach
- [x] Quy trình báo cáo đến cơ quan có thẩm quyền trong 72h

## D. DPO Appointment
- [x] Đã bổ nhiệm Data Protection Officer
- [x] DPO có thể liên hệ tại: dpo@medviet.example.vn

## E. Technical Controls (mapping từ requirements)
| NĐ13 Requirement | Technical Control | Status | Owner |
|-----------------|-------------------|--------|-------|
| Data minimization | PII anonymization pipeline (Presidio) | ✅ Done | AI Team |
| Access control | RBAC (Casbin) + ABAC (OPA) | ✅ Done | Platform Team |
| Encryption | Envelope encryption AES-256-GCM at rest, TLS 1.3 in transit | ✅ Done | Infra Team |
| Audit logging | API access logs with user, role, resource, action, status, timestamp | 🚧 In Progress | Platform Team |
| Breach detection | Prometheus alerts for unusual access volume and 403/401 spikes | 🚧 In Progress | Security Team |

## F. Implementation Notes

- Audit logging: bổ sung middleware FastAPI ghi JSON log cho mọi request vào SIEM/ELK, gồm `request_id`, username, role, endpoint, action, status code và latency; log giữ tối thiểu 180 ngày.
- Breach detection: cấu hình Prometheus scrape FastAPI metrics, cảnh báo khi có spike truy cập raw PII, nhiều request 401/403 liên tiếp, hoặc export restricted data ra destination ngoài VN.
- Consent management: lưu consent record trong bảng riêng, khóa theo `patient_id`, có timestamp, purpose và version của consent form; pipeline training chỉ dùng record còn hiệu lực.
- Data retention: raw PII chỉ giữ theo thời hạn hợp đồng/pháp lý; anonymized training data được version hóa và kiểm tra lại trước mỗi lần dùng cho model training.
