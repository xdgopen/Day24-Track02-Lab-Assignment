# Lab 24 Report: Data Governance & Security for AI Platform

**Sinh viên:** Nguyễn Danh Thành  
**MSSV:** 2A202600581  
**Project:** MedViet Data Governance Pipeline  
**Ngày thực hiện:** 30/06/2026

## 1. Mục tiêu

Xây dựng pipeline governance cho dữ liệu bệnh nhân MedViet gồm tạo dữ liệu giả lập, phát hiện/anonymize PII, phân quyền RBAC/OPA, mã hóa envelope encryption, kiểm tra data quality, security scan và checklist tuân thủ NĐ13/ISO 27001.

## 2. ENV cần thêm/cấu hình

Đã thêm file `.env.example` cho cấu hình local:

```bash
APP_ENV=local
DATA_DIR=./data
RAW_DATA_PATH=./data/raw/patients_raw.csv
ANON_DATA_PATH=./data/processed/patients_anonymized.csv
VAULT_MASTER_KEY_PATH=.vault_key
API_HOST=0.0.0.0
API_PORT=8000
PROMETHEUS_PORT=9090
GRAFANA_PORT=3000
MLFLOW_PORT=5000
```

Không commit `.vault_key`, `data/raw/`, file `.env` thật hoặc credential thật.

## 3. Commands đã thực hiện / cần tái chạy

```bash
cd medviet-governance
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Tùy chọn cài model tiếng Việt cho spaCy. Nếu không cài, detector vẫn dùng pattern fallback đủ cho test lab:

```bash
pip install pyvi
pip install --no-deps https://gitlab.com/trungtv/vi_spacy/-/raw/master/packages/vi_core_news_lg-3.6.0/dist/vi_core_news_lg-3.6.0.tar.gz
```

Sinh dữ liệu và tạo output anonymized:

```bash
python scripts/generate_data.py
python scripts/anonymize_data.py
```

Chạy test PII/RBAC/encryption:

```bash
pytest tests/test_pii.py -v --tb=short
python - <<'PY'
from src.encryption.vault import SimpleVault
vault = SimpleVault()
original = "Nguyen Van A - CCCD: 012345678901"
encrypted = vault.encrypt_data(original)
decrypted = vault.decrypt_data(encrypted)
assert decrypted == original
print("Encryption test passed")
PY
```

Chạy API và kiểm thử role:

```bash
uvicorn src.api.main:app --reload
curl -H "Authorization: Bearer token-bob" http://localhost:8000/api/patients/raw
curl -H "Authorization: Bearer token-alice" http://localhost:8000/api/patients/raw
curl -H "Authorization: Bearer token-carol" http://localhost:8000/api/metrics/aggregated
curl -X DELETE -H "Authorization: Bearer token-bob" http://localhost:8000/api/patients/abc123
```

Security scan và report:

```bash
brew install git-secrets trufflehog opa
git init
git secrets --install
git secrets --add 'CCCD[:\s]+\d{12}'
git secrets --add 'cccd[:\s]+\d{12}'
git secrets --add "password\s*=\s*['\"][^'\"]+['\"]"
git secrets --add "secret_key\s*=\s*['\"][^'\"]+['\"]"
git secrets --register-aws
chmod +x .github/hooks/pre-commit
cp .github/hooks/pre-commit .git/hooks/pre-commit

mkdir -p reports
pytest tests/ -v --tb=short > reports/test_results.txt
bandit -r src/ -f json -o reports/bandit_report.json
trufflehog filesystem src tests policies scripts compliance_checklist.md requirements.txt .env.example \
  --no-update --results=verified --no-color --log-level=-1 > reports/trufflehog_report.txt 2>&1
```

Ghi chú: `trufflehog git file://.` chỉ dùng sau khi repo đã có Git index/history. Với repo lab vừa `git init` và chưa có commit, lệnh này có thể fail vì thiếu `.git/index`; filesystem scan phù hợp hơn để quét working tree trước khi nộp.

OPA policy test:

```bash
echo '{
  "user": {"role": "ml_engineer"},
  "resource": "production_data",
  "action": "delete"
}' | opa eval -d policies/opa_policy.rego -I "data.medviet.data_access.allow"
```

Đóng gói bài nộp:

```bash
zip -r lab24_submission_nguyen_danh_thanh.zip \
    src/ tests/ policies/ data/processed/ \
    compliance_checklist.md reports/ requirements.txt
```

## 4. PII Columns

Các cột chứa PII hoặc dữ liệu nhạy cảm trong `patients_raw.csv`:

| Cột | Loại dữ liệu | Cách xử lý |
|---|---|---|
| `ho_ten` | Họ tên bệnh nhân | Replace bằng tên giả |
| `cccd` | Căn cước công dân 12 số | Replace bằng CCCD giả |
| `ngay_sinh` | Ngày sinh | Generalize thành `nam_sinh` |
| `so_dien_thoai` | Số điện thoại Việt Nam | Replace bằng số giả |
| `email` | Email | Replace bằng email giả |
| `dia_chi` | Địa chỉ | Replace bằng địa chỉ giả |
| `bac_si_phu_trach` | Tên bác sĩ | Replace bằng tên giả |
| `patient_id` | Pseudonymous identifier | Giữ nguyên vì đã là UUID |

Các cột giữ nguyên để training/analytics: `benh`, `ket_qua_xet_nghiem`, `ngay_kham`.

## 5. Kết quả triển khai

- PII Detection: custom recognizer cho `VN_CCCD`, `VN_PHONE`, `EMAIL_ADDRESS`, `PERSON`; fallback spaCy blank khi chưa có model tiếng Việt.
- Anonymization: thay thế họ tên, CCCD, phone, email, địa chỉ, bác sĩ; giữ nguyên thông tin bệnh/xét nghiệm phục vụ model training.
- RBAC API: Casbin policy cho `admin`, `ml_engineer`, `data_analyst`, `intern`; trả `401` khi thiếu token và `403` khi role không đủ quyền.
- Encryption: envelope encryption với KEK local và DEK per payload, dùng AES-256-GCM.
- Data Quality: kiểm tra row count, required columns, null values, CCCD/email replacement format.
- OPA: ABAC policy deny-by-default, chỉ cho role truy cập đúng resource/action; restricted data không được export ra ngoài Việt Nam.
- Compliance: checklist NĐ13 đã bổ sung DPO, audit logging, breach detection, consent và retention notes.

## 6. Kết quả kiểm thử final

### 6.1 Pytest

File kết quả: `reports/test_results.txt`

- Environment: macOS Darwin, Python 3.14.5, pytest 9.1.1.
- Kết quả: **6/6 tests passed** trong 3.65s.
- Các case pass:
  - `test_cccd_detected`
  - `test_phone_detected`
  - `test_email_detected`
  - `test_detection_rate_above_95_percent`
  - `test_pii_not_in_output`
  - `test_non_pii_columns_unchanged`
- Warning còn lại: spaCy cảnh báo model `vi_core_news_lg` 3.6.0 có thể không tương thích 100% với spaCy 3.8.13; không làm fail test.

### 6.2 Bandit SAST

File kết quả: `reports/bandit_report.json`

- Errors: 0.
- Findings: 4 LOW severity, HIGH confidence.
- Tất cả findings là `B311` tại `src/pii/anonymizer.py`, do dùng `random` để sinh CCCD/số điện thoại giả.
- Đánh giá: chấp nhận được cho dữ liệu fake/anonymization lab; khóa mã hóa thật dùng `os.urandom()` và AES-GCM trong `src/encryption/vault.py`.

### 6.3 TruffleHog

File kết quả: `reports/trufflehog_report.txt`

- Command đã chạy:

```bash
trufflehog filesystem src tests policies scripts compliance_checklist.md requirements.txt .env.example \
  --no-update --results=verified --no-color --log-level=-1 > reports/trufflehog_report.txt 2>&1
```

- Kết quả: command hoàn tất exit code 0, không có verified secret được in ra report.
- `.vault_key`, `.env`, `.venv/` và `data/raw/` đã được ignore trong `.gitignore` để tránh nộp/commit nhầm dữ liệu nhạy cảm.

## 7. Kết luận

Pipeline MedViet đã hoàn thành các yêu cầu chính của lab: PII detection/anonymization đạt test, RBAC/OPA policy được cấu hình, encryption round-trip có script kiểm thử, data quality/compliance checklist đã bổ sung, và security reports đã được sinh trong thư mục `reports/`.
