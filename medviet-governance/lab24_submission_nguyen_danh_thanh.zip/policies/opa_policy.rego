package medviet.data_access

import future.keywords.if
import future.keywords.in

# Default: deny all
default allow := false

# Admin được phép tất cả
allow if {
    input.user.role == "admin"
    not denied
}

# ML Engineer được đọc training data và model artifacts
allow if {
    input.user.role == "ml_engineer"
    input.resource in {"training_data", "model_artifacts"}
    input.action in {"read", "write"}
    not denied
}

# ML Engineer KHÔNG được delete production data
denied if {
    input.user.role == "ml_engineer"
    input.resource == "production_data"
    input.action == "delete"
}

# Data Analyst chỉ được đọc aggregated metrics và viết reports
allow if {
    input.user.role == "data_analyst"
    input.resource == "aggregated_metrics"
    input.action == "read"
    not denied
}

allow if {
    input.user.role == "data_analyst"
    input.resource == "reports"
    input.action == "write"
    not denied
}

# Intern chỉ được access sandbox
allow if {
    input.user.role == "intern"
    input.resource == "sandbox_data"
    input.action in {"read", "write"}
    not denied
}

# Rule: không ai được export restricted data ra ngoài VN servers
denied if {
    input.data_classification == "restricted"
    input.destination_country != "VN"
}
