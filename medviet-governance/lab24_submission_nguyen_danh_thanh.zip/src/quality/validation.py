"""Data quality checks for MedViet patient datasets."""

import re

import pandas as pd
import great_expectations as gx
from great_expectations.core.expectation_suite import ExpectationSuite

def build_patient_expectation_suite() -> ExpectationSuite:
    """
    Tạo expectation suite cho anonymized patient data.
    """
    context = gx.get_context()
    suite_name = "patient_data_suite"
    try:
        suite = context.add_expectation_suite(suite_name)
    except Exception:
        suite = context.get_expectation_suite(suite_name)

    # Lấy validator
    df = pd.read_csv("data/raw/patients_raw.csv")
    validator = context.sources.pandas_default.read_dataframe(df)

    # --- TASK: Thêm các expectations ---

    # 1. patient_id không được null
    validator.expect_column_values_to_not_be_null("patient_id")

    # 2. cccd phải có đúng 12 ký tự
    validator.expect_column_value_lengths_to_equal(
        column="cccd",
        value=12
    )

    # 3. ket_qua_xet_nghiem phải trong khoảng [0, 50]
    validator.expect_column_values_to_be_between(
        column="ket_qua_xet_nghiem",
        min_value=0,
        max_value=50
    )

    # 4. benh phải thuộc danh sách hợp lệ
    valid_conditions = ["Tiểu đường", "Huyết áp cao", "Tim mạch", "Khỏe mạnh"]
    validator.expect_column_values_to_be_in_set(
        column="benh",
        value_set=valid_conditions
    )

    # 5. email phải match regex pattern
    validator.expect_column_values_to_match_regex(
        column="email",
        regex=r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$"
    )

    # 6. Không được có duplicate patient_id
    validator.expect_column_values_to_be_unique(column="patient_id")

    validator.save_expectation_suite()
    return suite


def validate_anonymized_data(filepath: str) -> dict:
    """
    Validate anonymized data.
    Trả về dict: {"success": bool, "failed_checks": list, "stats": dict}
    """
    df = pd.read_csv(filepath)
    results = {
        "success": True,
        "failed_checks": [],
        "stats": {
            "total_rows": len(df),
            "columns": list(df.columns)
        }
    }

    def fail(message: str) -> None:
        results["success"] = False
        results["failed_checks"].append(message)

    if "cccd" in df.columns:
        invalid_cccd = ~df["cccd"].astype(str).str.match(r"^\d{12}$")
        if invalid_cccd.any():
            fail("cccd must contain 12-digit replacement values")

    required_columns = ["patient_id", "ho_ten", "cccd", "so_dien_thoai", "email", "benh"]
    missing_columns = [column for column in required_columns if column not in df.columns]
    if missing_columns:
        fail(f"missing required columns: {missing_columns}")
    else:
        null_columns = [column for column in required_columns if df[column].isna().any()]
        if null_columns:
            fail(f"null values found in required columns: {null_columns}")

    if "email" in df.columns:
        email_pattern = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
        invalid_email = ~df["email"].astype(str).map(lambda value: bool(email_pattern.match(value)))
        if invalid_email.any():
            fail("email contains invalid replacement values")

    try:
        original_rows = len(pd.read_csv("data/raw/patients_raw.csv"))
        if len(df) != original_rows:
            fail(f"row count mismatch: anonymized={len(df)}, raw={original_rows}")
    except FileNotFoundError:
        results["stats"]["raw_row_check"] = "skipped: data/raw/patients_raw.csv not found"

    return results
