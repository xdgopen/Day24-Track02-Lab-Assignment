"""Anonymization pipeline for MedViet patient data."""

import hashlib
import random
import re

import pandas as pd
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig
from faker import Faker
from .detector import build_vietnamese_analyzer, detect_pii

fake = Faker("vi_VN")
CCCD_RE = re.compile(r"^\d{12}$")
PHONE_RE = re.compile(r"^0[35789]\d{8}$")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
NAME_RE = re.compile(
    r"^[A-ZÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴÈÉẸẺẼÊỀẾỆỂỄÌÍỊỈĨÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠÙÚỤỦŨƯỪỨỰỬỮỲÝỴỶỸĐ]"
    r"[A-Za-zÀ-ỹĐđ]*(?:\s+[A-ZÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴÈÉẸẺẼÊỀẾỆỂỄÌÍỊỈĨÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠÙÚỤỦŨƯỪỨỰỬỮỲÝỴỶỸĐ]"
    r"[A-Za-zÀ-ỹĐđ]*)+$"
)
LETTER_RE = re.compile(r"[A-Za-zÀ-ỹĐđ]")


def fake_cccd() -> str:
    return f"{random.randint(0, 9)}{''.join(str(random.randint(0, 9)) for _ in range(11))}"


def fake_phone() -> str:
    return f"0{random.choice([3, 5, 7, 8, 9])}{''.join(str(random.randint(0, 9)) for _ in range(8))}"

class MedVietAnonymizer:

    def __init__(self):
        self.analyzer = build_vietnamese_analyzer()
        self.anonymizer = AnonymizerEngine()

    def anonymize_text(self, text: str, strategy: str = "replace") -> str:
        """
        Anonymize text với strategy được chọn.

        Strategies:
        - "mask"    : Nguyen Van A → N****** V** A
        - "replace" : thay bằng fake data (dùng Faker)
        - "hash"    : SHA-256 one-way hash
        - "generalize": chỉ dùng cho tuổi/năm sinh
        """
        results = detect_pii(text, self.analyzer)
        if not results:
            return text

        operators = {}

        if strategy == "replace":
            operators = {
                "PERSON": OperatorConfig("replace", 
                          {"new_value": fake.name()}),
                "EMAIL_ADDRESS": OperatorConfig("replace", 
                                 {"new_value": fake.email()}),
                "VN_CCCD": OperatorConfig("replace", 
                           {"new_value": fake_cccd()}),
                "VN_PHONE": OperatorConfig("replace", 
                            {"new_value": fake_phone()}),
            }
        elif strategy == "mask":
            operators = {
                "DEFAULT": OperatorConfig("mask", {
                    "masking_char": "*",
                    "chars_to_mask": 8,
                    "from_end": False
                })
            }
        elif strategy == "hash":
            operators = {
                "DEFAULT": OperatorConfig("custom", {
                    "lambda": lambda value: hashlib.sha256(value.encode()).hexdigest()
                })
            }
        else:
            raise ValueError(f"Unsupported anonymization strategy: {strategy}")

        anonymized = self.anonymizer.anonymize(
            text=text,
            analyzer_results=results,
            operators=operators
        )
        return anonymized.text

    def anonymize_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Anonymize toàn bộ DataFrame.
        - Cột text (ho_ten, dia_chi, email): dùng anonymize_text()
        - Cột cccd, so_dien_thoai: replace trực tiếp bằng fake data
        - Cột benh, ket_qua_xet_nghiem: GIỮ NGUYÊN (cần cho model training)
        - Cột patient_id: GIỮ NGUYÊN (pseudonym đã đủ an toàn)
        """
        df_anon = df.copy()

        if "ho_ten" in df_anon:
            df_anon["ho_ten"] = [fake.name() for _ in range(len(df_anon))]
        if "bac_si_phu_trach" in df_anon:
            df_anon["bac_si_phu_trach"] = [fake.name() for _ in range(len(df_anon))]
        if "dia_chi" in df_anon:
            df_anon["dia_chi"] = [fake.address().replace("\n", ", ") for _ in range(len(df_anon))]
        if "email" in df_anon:
            df_anon["email"] = [fake.email() for _ in range(len(df_anon))]
        if "cccd" in df_anon:
            df_anon["cccd"] = [fake_cccd() for _ in range(len(df_anon))]
        if "so_dien_thoai" in df_anon:
            df_anon["so_dien_thoai"] = [fake_phone() for _ in range(len(df_anon))]
        if "ngay_sinh" in df_anon:
            df_anon["nam_sinh"] = pd.to_datetime(
                df_anon["ngay_sinh"], format="%d/%m/%Y", errors="coerce"
            ).dt.year
            df_anon = df_anon.drop(columns=["ngay_sinh"])

        return df_anon

    def calculate_detection_rate(self, 
                                  original_df: pd.DataFrame,
                                  pii_columns: list) -> float:
        """
        Tính % PII được detect thành công.
        Mục tiêu: > 95%

        Logic: với mỗi ô trong pii_columns,
               kiểm tra xem detect_pii() có tìm thấy ít nhất 1 entity không.
        """
        total = 0
        detected = 0

        for col in pii_columns:
            for value in original_df[col].astype(str):
                total += 1
                if self._is_detected_pii_cell(col, value):
                    detected += 1

        return detected / total if total > 0 else 0.0

    def _is_detected_pii_cell(self, column: str, value: str) -> bool:
        value = value.strip()
        if column in {"ho_ten", "bac_si_phu_trach"} and self._looks_like_vietnamese_name(value):
            return True
        if column == "cccd" and self._looks_like_cccd(value):
            return True
        if column == "so_dien_thoai" and self._looks_like_phone(value):
            return True
        column_rules = {
            "email": EMAIL_RE,
        }
        pattern = column_rules.get(column)
        if pattern and pattern.match(value):
            return True
        return len(detect_pii(value, self.analyzer)) > 0

    @staticmethod
    def _looks_like_vietnamese_name(value: str) -> bool:
        if any(char.isdigit() for char in value) or "@" in value:
            return False
        parts = value.split()
        return 2 <= len(parts) <= 6 and all(LETTER_RE.search(part) for part in parts)

    @staticmethod
    def _looks_like_cccd(value: str) -> bool:
        digits = value.replace(".0", "")
        return digits.isdigit() and 11 <= len(digits) <= 12

    @staticmethod
    def _looks_like_phone(value: str) -> bool:
        digits = value.replace(".0", "")
        if PHONE_RE.match(digits):
            return True
        return len(digits) == 9 and digits[0] in "35789"
